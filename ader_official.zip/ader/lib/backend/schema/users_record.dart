import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'users_record.g.dart';

abstract class UsersRecord implements Built<UsersRecord, UsersRecordBuilder> {
  static Serializer<UsersRecord> get serializer => _$usersRecordSerializer;

  String? get email;

  @BuiltValueField(wireName: 'display_name')
  String? get displayName;

  @BuiltValueField(wireName: 'phone_number')
  String? get phoneNumber;

  String? get password;

  @BuiltValueField(wireName: 'created_time')
  DateTime? get createdTime;

  @BuiltValueField(wireName: 'profile_picture')
  String? get profilePicture;

  @BuiltValueField(wireName: 'photo_url')
  String? get photoUrl;

  String? get uid;

  @BuiltValueField(wireName: 'needs_albuterol')
  bool? get needsAlbuterol;

  @BuiltValueField(wireName: 'needs_aspirin')
  bool? get needsAspirin;

  @BuiltValueField(wireName: 'needs_epi')
  bool? get needsEpi;

  @BuiltValueField(wireName: 'needs_prednisone')
  bool? get needsPrednisone;

  @BuiltValueField(wireName: 'knows_cpr')
  bool? get knowsCpr;

  @BuiltValueField(wireName: 'needs_cpr')
  bool? get needsCpr;

  @BuiltValueField(wireName: 'is_emt')
  bool? get isEmt;

  @BuiltValueField(wireName: 'needs_emt')
  bool? get needsEmt;

  @BuiltValueField(wireName: 'has_albuterol')
  bool? get hasAlbuterol;

  @BuiltValueField(wireName: 'has_aspirin')
  bool? get hasAspirin;

  @BuiltValueField(wireName: 'has_epi')
  bool? get hasEpi;

  @BuiltValueField(wireName: 'has_prednisone')
  bool? get hasPrednisone;

  @BuiltValueField(wireName: 'current_loc')
  LatLng? get currentLoc;

  @BuiltValueField(wireName: 'current_status')
  bool? get currentStatus;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(UsersRecordBuilder builder) => builder
    ..email = ''
    ..displayName = ''
    ..phoneNumber = ''
    ..password = ''
    ..profilePicture = ''
    ..photoUrl = ''
    ..uid = ''
    ..needsAlbuterol = false
    ..needsAspirin = false
    ..needsEpi = false
    ..needsPrednisone = false
    ..knowsCpr = false
    ..needsCpr = false
    ..isEmt = false
    ..needsEmt = false
    ..hasAlbuterol = false
    ..hasAspirin = false
    ..hasEpi = false
    ..hasPrednisone = false
    ..currentStatus = false;

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  UsersRecord._();
  factory UsersRecord([void Function(UsersRecordBuilder) updates]) =
      _$UsersRecord;

  static UsersRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? phoneNumber,
  String? password,
  DateTime? createdTime,
  String? profilePicture,
  String? photoUrl,
  String? uid,
  bool? needsAlbuterol,
  bool? needsAspirin,
  bool? needsEpi,
  bool? needsPrednisone,
  bool? knowsCpr,
  bool? needsCpr,
  bool? isEmt,
  bool? needsEmt,
  bool? hasAlbuterol,
  bool? hasAspirin,
  bool? hasEpi,
  bool? hasPrednisone,
  LatLng? currentLoc,
  bool? currentStatus,
}) {
  final firestoreData = serializers.toFirestore(
    UsersRecord.serializer,
    UsersRecord(
      (u) => u
        ..email = email
        ..displayName = displayName
        ..phoneNumber = phoneNumber
        ..password = password
        ..createdTime = createdTime
        ..profilePicture = profilePicture
        ..photoUrl = photoUrl
        ..uid = uid
        ..needsAlbuterol = needsAlbuterol
        ..needsAspirin = needsAspirin
        ..needsEpi = needsEpi
        ..needsPrednisone = needsPrednisone
        ..knowsCpr = knowsCpr
        ..needsCpr = needsCpr
        ..isEmt = isEmt
        ..needsEmt = needsEmt
        ..hasAlbuterol = hasAlbuterol
        ..hasAspirin = hasAspirin
        ..hasEpi = hasEpi
        ..hasPrednisone = hasPrednisone
        ..currentLoc = currentLoc
        ..currentStatus = currentStatus,
    ),
  );

  return firestoreData;
}
