import '../auth/auth_util.dart';
import '../backend/backend.dart';
import '../flutter_flow/flutter_flow_google_map.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../help_coming/help_coming_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shake/shake.dart';

class HelpPageWidget extends StatefulWidget {
  const HelpPageWidget({Key? key}) : super(key: key);

  @override
  _HelpPageWidgetState createState() => _HelpPageWidgetState();
}

class _HelpPageWidgetState extends State<HelpPageWidget> {
  LatLng? currentUserLocationValue;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  late ShakeDetector shakeDetector;
  var shakeActionInProgress = false;
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();
  bool? checkboxListTileValue1;
  bool? checkboxListTileValue2;
  bool? checkboxListTileValue3;

  @override
  void initState() {
    super.initState();
    // On shake action.
    shakeDetector = ShakeDetector.autoStart(
      onPhoneShake: () async {
        if (shakeActionInProgress) {
          return;
        }
        shakeActionInProgress = true;
        try {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => HelpPageWidget(),
            ),
          );
        } finally {
          shakeActionInProgress = false;
        }
      },
      shakeThresholdGravity: 1.5,
    );

    getCurrentUserLocation(defaultLocation: LatLng(0.0, 0.0), cached: true)
        .then((loc) => setState(() => currentUserLocationValue = loc));
  }

  @override
  void dispose() {
    shakeDetector.stopListening();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (currentUserLocationValue == null) {
      return Center(
        child: SizedBox(
          width: 50,
          height: 50,
          child: CircularProgressIndicator(
            color: FlutterFlowTheme.of(context).primaryColor,
          ),
        ),
      );
    }
    return StreamBuilder<UsersRecord>(
      stream: UsersRecord.getDocument(currentUserReference!),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Center(
            child: SizedBox(
              width: 50,
              height: 50,
              child: CircularProgressIndicator(
                color: FlutterFlowTheme.of(context).primaryColor,
              ),
            ),
          );
        }
        final helpPageUsersRecord = snapshot.data!;
        return Scaffold(
          key: scaffoldKey,
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            backgroundColor: Color(0xFFC70000),
            automaticallyImplyLeading: true,
            actions: [],
            centerTitle: true,
            elevation: 4,
          ),
          backgroundColor: Color(0xFFE6E3E3),
          body: SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  FFLocalizations.of(context).getText(
                    'y0tho7dn' /* ADER */,
                  ),
                  style: FlutterFlowTheme.of(context).bodyText1.override(
                        fontFamily: 'Orbitron',
                        color: Color(0xFF970000),
                        fontSize: 80,
                        fontWeight: FontWeight.w800,
                        decoration: TextDecoration.underline,
                      ),
                ),
                Align(
                  alignment: AlignmentDirectional(-0.8, 0),
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(80, 15, 0, 0),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        '67vxag8v' /* Current Location: */,
                      ),
                      textAlign: TextAlign.start,
                      style: FlutterFlowTheme.of(context).title1.override(
                            fontFamily: 'Lexend Deca',
                            fontSize: 24,
                          ),
                    ),
                  ),
                ),
                Expanded(
                  child: StreamBuilder<UsersRecord>(
                    stream: UsersRecord.getDocument(currentUserReference!),
                    builder: (context, snapshot) {
                      // Customize what your widget looks like when it's loading.
                      if (!snapshot.hasData) {
                        return Center(
                          child: SizedBox(
                            width: 50,
                            height: 50,
                            child: CircularProgressIndicator(
                              color: FlutterFlowTheme.of(context).primaryColor,
                            ),
                          ),
                        );
                      }
                      final googleMapUsersRecord = snapshot.data!;
                      return FlutterFlowGoogleMap(
                        controller: googleMapsController,
                        onCameraIdle: (latLng) => googleMapsCenter = latLng,
                        initialLocation: googleMapsCenter ??=
                            currentUserLocationValue!,
                        markers: [
                          if (helpPageUsersRecord != null)
                            FlutterFlowMarker(
                              helpPageUsersRecord.reference.path,
                              helpPageUsersRecord.currentLoc!,
                            ),
                        ],
                        markerColor: GoogleMarkerColor.violet,
                        mapType: MapType.normal,
                        style: GoogleMapStyle.standard,
                        initialZoom: 10,
                        allowInteraction: true,
                        allowZoom: true,
                        showZoomControls: true,
                        showLocation: true,
                        showCompass: false,
                        showMapToolbar: false,
                        showTraffic: false,
                        centerMapOnMarkerTap: true,
                      );
                    },
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(-0.8, 0),
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(60, 15, 0, 5),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        'edquqa1f' /* Additional Assistance: */,
                      ),
                      textAlign: TextAlign.start,
                      style: FlutterFlowTheme.of(context).title1.override(
                            fontFamily: 'Lexend Deca',
                            fontSize: 24,
                          ),
                    ),
                  ),
                ),
                Theme(
                  data: ThemeData(
                    unselectedWidgetColor: Color(0xFF95A1AC),
                  ),
                  child: CheckboxListTile(
                    value: checkboxListTileValue1 ??= false,
                    onChanged: (newValue) =>
                        setState(() => checkboxListTileValue1 = newValue!),
                    title: Text(
                      FFLocalizations.of(context).getText(
                        'fsvxu1vo' /* I require an EMT! */,
                      ),
                      style: FlutterFlowTheme.of(context).title3.override(
                            fontFamily: 'Lexend Deca',
                            color: Color(0xFFC70000),
                            fontSize: 25,
                          ),
                    ),
                    tileColor: Color(0xFFE6EBEF),
                    activeColor: Color(0xFFC70000),
                    dense: false,
                    controlAffinity: ListTileControlAffinity.trailing,
                  ),
                ),
                Theme(
                  data: ThemeData(
                    unselectedWidgetColor: Color(0xFF95A1AC),
                  ),
                  child: CheckboxListTile(
                    value: checkboxListTileValue2 ??= false,
                    onChanged: (newValue) =>
                        setState(() => checkboxListTileValue2 = newValue!),
                    title: Text(
                      FFLocalizations.of(context).getText(
                        'duhnklxv' /* Someone requires CPR! */,
                      ),
                      style: FlutterFlowTheme.of(context).title3.override(
                            fontFamily: 'Lexend Deca',
                            color: Color(0xFFC70000),
                            fontSize: 25,
                          ),
                    ),
                    tileColor: Color(0xFFE6EBEF),
                    activeColor: Color(0xFFC70000),
                    dense: false,
                    controlAffinity: ListTileControlAffinity.trailing,
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(-0.8, 0),
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(120, 15, 0, 5),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        '4awc31wq' /* Disclosure: */,
                      ),
                      textAlign: TextAlign.start,
                      style: FlutterFlowTheme.of(context).title1.override(
                            fontFamily: 'Lexend Deca',
                            fontSize: 24,
                          ),
                    ),
                  ),
                ),
                Theme(
                  data: ThemeData(
                    unselectedWidgetColor: Color(0xFF95A1AC),
                  ),
                  child: CheckboxListTile(
                    value: checkboxListTileValue3 ??= true,
                    onChanged: (newValue) =>
                        setState(() => checkboxListTileValue3 = newValue!),
                    title: Text(
                      FFLocalizations.of(context).getText(
                        'ciyj9rxx' /* I consent to sharing my locati... */,
                      ),
                      style: FlutterFlowTheme.of(context).title3.override(
                            fontFamily: 'Lexend Deca',
                            color: Color(0xFFC70000),
                            fontSize: 20,
                          ),
                    ),
                    tileColor: Color(0xFFE6EBEF),
                    activeColor: Color(0xFFC70000),
                    dense: false,
                    controlAffinity: ListTileControlAffinity.trailing,
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 25),
                  child: FFButtonWidget(
                    onPressed: () async {
                      currentUserLocationValue = await getCurrentUserLocation(
                          defaultLocation: LatLng(0.0, 0.0));
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HelpComingWidget(),
                        ),
                      );

                      final usersUpdateData = createUsersRecordData(
                        currentLoc: currentUserLocationValue,
                        currentStatus: true,
                      );
                      await currentUserReference!.update(usersUpdateData);
                    },
                    text: FFLocalizations.of(context).getText(
                      'qaj5qc9k' /* Send SOS */,
                    ),
                    options: FFButtonOptions(
                      width: 300,
                      height: 60,
                      color: Color(0xFFC70000),
                      textStyle:
                          FlutterFlowTheme.of(context).subtitle2.override(
                                fontFamily: 'Lexend Deca',
                                color: Color(0xFFE6EBEF),
                                fontSize: 30,
                              ),
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).grayDark,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(90),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
