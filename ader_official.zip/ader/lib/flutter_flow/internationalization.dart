import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'es'];

  String get languageCode => locale.toString();
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? esText = '',
  }) =>
      [enText, esText][languageIndex] ?? '';
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      FFLocalizations.languages().contains(locale.toString());

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // completeProfile
  {
    'skjzr8f3': {
      'en': 'Enter your name:',
      'es': '',
    },
    '5xo0m673': {
      'en': 'Your Name',
      'es': '',
    },
    'g878dno4': {
      'en': 'What name do you go by?',
      'es': '',
    },
    '3627d32d': {
      'en': 'List your medications:',
      'es': '',
    },
    'xo0jtj0j': {
      'en': 'Albuterol',
      'es': '',
    },
    'v0fm5lg4': {
      'en': 'ProAir, Ventolin, etc. (Prescribed)',
      'es': '',
    },
    'ycnlh0lf': {
      'en': 'Aspirin',
      'es': '',
    },
    'vnhzcwo8': {
      'en': 'Chewable, Capsuled, etc.',
      'es': '',
    },
    'na5hnkxl': {
      'en': 'Epinephrine',
      'es': '',
    },
    '9tya2yrj': {
      'en': 'EpiPen, etc. (Prescribed)',
      'es': '',
    },
    'pwycoc7r': {
      'en': 'Prednisone / Prednisolone',
      'es': '',
    },
    'ev7cpggw': {
      'en': 'Deltasone, Rayos, etc. (Prescribed)',
      'es': '',
    },
    'c99rgmw0': {
      'en': 'List carried medications:',
      'es': '',
    },
    'git9qfx8': {
      'en': 'Albuterol',
      'es': '',
    },
    '3spo9cic': {
      'en': 'ProAir, Ventolin, etc. (Prescribed)',
      'es': '',
    },
    'm4a4y310': {
      'en': 'Aspirin',
      'es': '',
    },
    '5uwl6wsl': {
      'en': 'Chewable, Capsuled, etc.',
      'es': '',
    },
    'obtrq4u1': {
      'en': 'Epinephrine',
      'es': '',
    },
    '5lqbxxrw': {
      'en': 'EpiPen, etc. (Prescribed)',
      'es': '',
    },
    '7dspw14a': {
      'en': 'Prednisone / Prednisolone',
      'es': '',
    },
    '3oghqzj4': {
      'en': 'Deltasone, Rayos, etc. (Prescribed)',
      'es': '',
    },
    'dskm7k9e': {
      'en': 'List any qualifications:',
      'es': '',
    },
    'dvk81mxx': {
      'en': 'CPR',
      'es': '',
    },
    'qw7gsdji': {
      'en':
          'I have underwent AHA or equivalent CPR training and/or certification.',
      'es': '',
    },
    '6e7x3y4a': {
      'en': 'EMT',
      'es': '',
    },
    'jkogwlf0': {
      'en': 'I am a state-certified and/or nationally-registered EMT basic. ',
      'es': '',
    },
    '390td496': {
      'en': 'Save Profile',
      'es': '',
    },
    'dsnp4d65': {
      'en': 'Complete Your Profile',
      'es': '',
    },
    'cip4bulg': {
      'en': 'Home',
      'es': '',
    },
  },
  // helpPage
  {
    'y0tho7dn': {
      'en': 'ADER',
      'es': '',
    },
    '67vxag8v': {
      'en': 'Current Location:',
      'es': '',
    },
    'edquqa1f': {
      'en': 'Additional Assistance:',
      'es': '',
    },
    'fsvxu1vo': {
      'en': 'I require an EMT!',
      'es': '',
    },
    'duhnklxv': {
      'en': 'Someone requires CPR!',
      'es': '',
    },
    '4awc31wq': {
      'en': 'Disclosure:',
      'es': '',
    },
    'ciyj9rxx': {
      'en': 'I consent to sharing my location with nearby Ader users.',
      'es': '',
    },
    'qaj5qc9k': {
      'en': 'Send SOS',
      'es': '',
    },
  },
  // mainPage
  {
    'jl8c253i': {
      'en': 'ADER',
      'es': '',
    },
    '801ysi6o': {
      'en': 'Users that request help',
      'es': '',
    },
    'gfx4pu5k': {
      'en': 'SOS',
      'es': '',
    },
    'bn1krp1b': {
      'en': 'Home',
      'es': '',
    },
  },
  // SignIn
  {
    'bcvpl0wx': {
      'en': 'ADER',
      'es': '',
    },
    '3odj6dcv': {
      'en': 'Log In',
      'es': '',
    },
    'yk3sy1k9': {
      'en': 'Welcome Back!',
      'es': '',
    },
    'o0cs2ubv': {
      'en': 'Email Address',
      'es': '',
    },
    'h1zonuwl': {
      'en': '',
      'es': '',
    },
    'yzg0a16o': {
      'en': 'Password',
      'es': '',
    },
    'zkru4nh9': {
      'en': '',
      'es': '',
    },
    'c7veygk3': {
      'en': 'Sign In',
      'es': '',
    },
    'ncxonweq': {
      'en': 'Create an Account',
      'es': '',
    },
    '09liwrqf': {
      'en': 'Sign Up Today!',
      'es': '',
    },
    '384a9fft': {
      'en': 'Email Address',
      'es': '',
    },
    'doxw1y7k': {
      'en': '',
      'es': '',
    },
    'yw1p78or': {
      'en': 'Choose Password',
      'es': '',
    },
    'mumlru50': {
      'en': '',
      'es': '',
    },
    'qrtc4rey': {
      'en': 'Confirm Password',
      'es': '',
    },
    'ec5auwlf': {
      'en': '',
      'es': '',
    },
    '2hhxjeiy': {
      'en': 'Create Account',
      'es': '',
    },
    'luu1kd5b': {
      'en': 'Home',
      'es': '',
    },
  },
  // profilePage
  {
    'j3oz30gv': {
      'en': 'Your information:',
      'es': '',
    },
    'uzyglhdr': {
      'en': 'Name:',
      'es': '',
    },
    'mcoh3juj': {
      'en': 'Email:',
      'es': '',
    },
    'xnvia8s5': {
      'en': 'Your medication:',
      'es': '',
    },
    'v62g5oce': {
      'en': 'Albuterol',
      'es': '',
    },
    'joshwp72': {
      'en': 'ProAir, Ventolin, etc. (Prescribed)',
      'es': '',
    },
    'wc7kt4yf': {
      'en': 'Aspirin',
      'es': '',
    },
    'nfhgm9pi': {
      'en': 'Chewable, Capsuled, etc.',
      'es': '',
    },
    'lpxolwct': {
      'en': 'Epinephrine',
      'es': '',
    },
    'xbws7git': {
      'en': 'EpiPen, etc. (Prescribed)',
      'es': '',
    },
    '8ub1vkbw': {
      'en': 'Prednisone / Prednisolone',
      'es': '',
    },
    '17qq5wo7': {
      'en': 'Deltasone, Rayos, etc. (Prescribed)',
      'es': '',
    },
    'itkzglux': {
      'en': 'Your carried medication:',
      'es': '',
    },
    't4mtbn2w': {
      'en': 'Albuterol',
      'es': '',
    },
    'by3i77yz': {
      'en': 'ProAir, Ventolin, etc. (Prescribed)',
      'es': '',
    },
    'kjluflbq': {
      'en': 'Aspirin',
      'es': '',
    },
    'zpmepdc5': {
      'en': 'Chewable, Capsuled, etc.',
      'es': '',
    },
    '4qctrrgv': {
      'en': 'Epinephrine',
      'es': '',
    },
    'm9s77vow': {
      'en': 'EpiPen, etc. (Prescribed)',
      'es': '',
    },
    'zeq7seq8': {
      'en': 'Prednisone / Prednisolone',
      'es': '',
    },
    'cq08uy1m': {
      'en': 'Deltasone, Rayos, etc. (Prescribed)',
      'es': '',
    },
    'cme57cn4': {
      'en': 'Your qualifications:',
      'es': '',
    },
    '2jonk2ys': {
      'en': 'CPR',
      'es': '',
    },
    'dyqfhwh5': {
      'en':
          'I have underwent AHA or equivalent CPR training and/or certification.',
      'es': '',
    },
    'h1s1q95f': {
      'en': 'EMT',
      'es': '',
    },
    'sxv2byu3': {
      'en': 'I am a state-certified and/or nationally-registered EMT basic. ',
      'es': '',
    },
    'am1j6jbo': {
      'en': 'Apply Changes',
      'es': '',
    },
    'y4kvsxmf': {
      'en': 'Log Out',
      'es': '',
    },
    '1cd2mzgx': {
      'en': 'Home',
      'es': '',
    },
  },
  // helpComing
  {
    'x51fbxb5': {
      'en': 'Help is coming!',
      'es': '',
    },
    'h56pznqr': {
      'en': 'Your Location:',
      'es': '',
    },
    '90822hjm': {
      'en': 'Resolved',
      'es': '',
    },
    '1scznj8v': {
      'en': 'Sit Tight!',
      'es': '',
    },
    'yec1xh06': {
      'en': 'Home',
      'es': '',
    },
  },
  // friendList
  {
    '4w6kkxbo': {
      'en': 'Alex Edwards',
      'es': '',
    },
    'p74a3pnr': {
      'en': '[userEmail]',
      'es': '',
    },
  },
  // emptyList
  {
    'kg54mfru': {
      'en': 'No Messages',
      'es': '',
    },
    'ywqp72vs': {
      'en':
          'Seems you don\'t have any messages here, search your friends list in order to get started.',
      'es': '',
    },
    '6palgfiu': {
      'en': 'Find Friends',
      'es': '',
    },
  },
  // Miscellaneous
  {
    '2d5t4us9': {
      'en': '',
      'es': '',
    },
    'zdb6ilx5': {
      'en': '',
      'es': '',
    },
    'lzg3qi7e': {
      'en': '',
      'es': '',
    },
    'fuhm6cmq': {
      'en': '',
      'es': '',
    },
    'x7p81yea': {
      'en': '',
      'es': '',
    },
    'eet96eow': {
      'en': '',
      'es': '',
    },
    'xwe0fmz4': {
      'en': '',
      'es': '',
    },
    '4o2r7fiz': {
      'en': '',
      'es': '',
    },
    'w1e0iszo': {
      'en': '',
      'es': '',
    },
    'tfpo68wt': {
      'en': '',
      'es': '',
    },
    '8zkut488': {
      'en': '',
      'es': '',
    },
    '5jvq1dwg': {
      'en': '',
      'es': '',
    },
    'bu77g3xs': {
      'en': '',
      'es': '',
    },
    'g2cfofom': {
      'en': '',
      'es': '',
    },
    '4vd6aw0y': {
      'en': '',
      'es': '',
    },
    'rb6syvjt': {
      'en': '',
      'es': '',
    },
    'cqrg1y2p': {
      'en': '',
      'es': '',
    },
    'wdza192q': {
      'en': '',
      'es': '',
    },
    '6rqngxfu': {
      'en': '',
      'es': '',
    },
    'qn3l2kn4': {
      'en': '',
      'es': '',
    },
    'bbdg8omc': {
      'en': '',
      'es': '',
    },
    '602stjxp': {
      'en': '',
      'es': '',
    },
    'aqepom4q': {
      'en': '',
      'es': '',
    },
  },
].reduce((a, b) => a..addAll(b));
