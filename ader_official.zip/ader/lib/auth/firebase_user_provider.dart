import 'package:firebase_auth/firebase_auth.dart';
import 'package:rxdart/rxdart.dart';

class AderFirebaseUser {
  AderFirebaseUser(this.user);
  User? user;
  bool get loggedIn => user != null;
}

AderFirebaseUser? currentUser;
bool get loggedIn => currentUser?.loggedIn ?? false;
Stream<AderFirebaseUser> aderFirebaseUserStream() => FirebaseAuth.instance
    .authStateChanges()
    .debounce((user) => user == null && !loggedIn
        ? TimerStream(true, const Duration(seconds: 1))
        : Stream.value(user))
    .map<AderFirebaseUser>((user) => currentUser = AderFirebaseUser(user));
