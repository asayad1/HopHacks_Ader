import '../auth/auth_util.dart';
import '../backend/backend.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../sign_in/sign_in_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ProfilePageWidget extends StatefulWidget {
  const ProfilePageWidget({Key? key}) : super(key: key);

  @override
  _ProfilePageWidgetState createState() => _ProfilePageWidgetState();
}

class _ProfilePageWidgetState extends State<ProfilePageWidget> {
  bool? albterolCarryCheckValue;
  bool? albterolCheckValue;
  bool? aspirinCheckValue;
  bool? epiCheckValue;
  bool? prednisoneCheckValue;
  bool? aspirinCarryCheckValue;
  bool? epiCarryCheckValue;
  bool? prednisoneCarryCheckValue;
  bool? cprCheckValue;
  bool? emtCheckValue;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color(0xFFC70000),
        automaticallyImplyLeading: true,
        actions: [],
        centerTitle: true,
        elevation: 4,
      ),
      backgroundColor: Color(0xFFE6E3E3),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Align(
                  alignment: AlignmentDirectional(-0.8, 0),
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 15, 0, 0),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        'j3oz30gv' /* Your information: */,
                      ),
                      textAlign: TextAlign.start,
                      style: FlutterFlowTheme.of(context).title1.override(
                            fontFamily: 'Lexend Deca',
                            fontSize: 24,
                          ),
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: ListTile(
                    title: Text(
                      FFLocalizations.of(context).getText(
                        'uzyglhdr' /* Name: */,
                      ),
                      style: FlutterFlowTheme.of(context).title3.override(
                            fontFamily: 'Lexend Deca',
                            color: Color(0xFFC70000),
                          ),
                    ),
                    subtitle: Text(
                      currentUserDisplayName,
                      style: FlutterFlowTheme.of(context).subtitle2,
                    ),
                    trailing: Icon(
                      Icons.accessibility_new,
                      color: Color(0xFF303030),
                      size: 40,
                    ),
                    tileColor: Color(0xFFE6E3E3),
                    dense: false,
                  ),
                ),
                ListTile(
                  title: Text(
                    FFLocalizations.of(context).getText(
                      'mcoh3juj' /* Email: */,
                    ),
                    style: FlutterFlowTheme.of(context).title3.override(
                          fontFamily: 'Lexend Deca',
                          color: Color(0xFFC70000),
                        ),
                  ),
                  subtitle: Text(
                    currentUserEmail,
                    style: FlutterFlowTheme.of(context).subtitle2,
                  ),
                  trailing: Icon(
                    Icons.email,
                    color: Color(0xFF303030),
                    size: 35,
                  ),
                  tileColor: Color(0xFFE6E3E3),
                  dense: false,
                ),
                Align(
                  alignment: AlignmentDirectional(-0.8, 0),
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 15, 0, 0),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        'xnvia8s5' /* Your medication: */,
                      ),
                      textAlign: TextAlign.start,
                      style: FlutterFlowTheme.of(context).title1.override(
                            fontFamily: 'Lexend Deca',
                            fontSize: 24,
                          ),
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: albterolCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.needsAlbuterol, false),
                      onChanged: (newValue) =>
                          setState(() => albterolCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          'v62g5oce' /* Albuterol */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'joshwp72' /* ProAir, Ventolin, etc. (Prescr... */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: aspirinCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.needsAspirin, false),
                      onChanged: (newValue) =>
                          setState(() => aspirinCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          'wc7kt4yf' /* Aspirin */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'nfhgm9pi' /* Chewable, Capsuled, etc. */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: epiCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.needsEpi, false),
                      onChanged: (newValue) =>
                          setState(() => epiCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          'lpxolwct' /* Epinephrine */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'xbws7git' /* EpiPen, etc. (Prescribed) */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: prednisoneCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.needsPrednisone, false),
                      onChanged: (newValue) =>
                          setState(() => prednisoneCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          '8ub1vkbw' /* Prednisone / Prednisolone */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          '17qq5wo7' /* Deltasone, Rayos, etc. (Prescr... */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(-0.8, 0),
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(10, 15, 0, 0),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        'itkzglux' /* Your carried medication: */,
                      ),
                      textAlign: TextAlign.start,
                      style: FlutterFlowTheme.of(context).title1.override(
                            fontFamily: 'Lexend Deca',
                            fontSize: 24,
                          ),
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: albterolCarryCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.hasAlbuterol, false),
                      onChanged: (newValue) =>
                          setState(() => albterolCarryCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          't4mtbn2w' /* Albuterol */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'by3i77yz' /* ProAir, Ventolin, etc. (Prescr... */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: aspirinCarryCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.hasAspirin, false),
                      onChanged: (newValue) =>
                          setState(() => aspirinCarryCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          'kjluflbq' /* Aspirin */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'zpmepdc5' /* Chewable, Capsuled, etc. */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: epiCarryCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.hasEpi, false),
                      onChanged: (newValue) =>
                          setState(() => epiCarryCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          '4qctrrgv' /* Epinephrine */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'm9s77vow' /* EpiPen, etc. (Prescribed) */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: prednisoneCarryCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.hasPrednisone, false),
                      onChanged: (newValue) =>
                          setState(() => prednisoneCarryCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          'zeq7seq8' /* Prednisone / Prednisolone */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'cq08uy1m' /* Deltasone, Rayos, etc. (Prescr... */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(-0.8, 0),
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(5, 15, 0, 0),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        'cme57cn4' /* Your qualifications: */,
                      ),
                      textAlign: TextAlign.start,
                      style: FlutterFlowTheme.of(context).title1.override(
                            fontFamily: 'Lexend Deca',
                            fontSize: 24,
                          ),
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: cprCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.knowsCpr, false),
                      onChanged: (newValue) =>
                          setState(() => cprCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          '2jonk2ys' /* CPR */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'dyqfhwh5' /* I have underwent AHA or equiva... */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                AuthUserStreamWidget(
                  child: Theme(
                    data: ThemeData(
                      unselectedWidgetColor: Color(0xFF95A1AC),
                    ),
                    child: CheckboxListTile(
                      value: emtCheckValue ??= valueOrDefault<bool>(
                          currentUserDocument?.isEmt, false),
                      onChanged: (newValue) =>
                          setState(() => emtCheckValue = newValue!),
                      title: Text(
                        FFLocalizations.of(context).getText(
                          'h1s1q95f' /* EMT */,
                        ),
                        style: FlutterFlowTheme.of(context).title3.override(
                              fontFamily: 'Lexend Deca',
                              color: Color(0xFFC70000),
                            ),
                      ),
                      subtitle: Text(
                        FFLocalizations.of(context).getText(
                          'sxv2byu3' /* I am a state-certified and/or ... */,
                        ),
                        style: FlutterFlowTheme.of(context).subtitle2,
                      ),
                      tileColor: Color(0xFFE6E3E3),
                      activeColor: Color(0xFFC70000),
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                    ),
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(40, 20, 40, 0),
                      child: FFButtonWidget(
                        onPressed: () async {
                          final usersUpdateData = createUsersRecordData(
                            needsAlbuterol: albterolCheckValue,
                            needsAspirin: aspirinCheckValue,
                            needsEpi: epiCheckValue,
                            needsPrednisone: prednisoneCheckValue,
                            hasAlbuterol: albterolCarryCheckValue,
                            hasAspirin: aspirinCarryCheckValue,
                            hasEpi: epiCarryCheckValue,
                            hasPrednisone: prednisoneCarryCheckValue,
                            knowsCpr: cprCheckValue,
                            isEmt: emtCheckValue,
                          );
                          await currentUserReference!.update(usersUpdateData);
                        },
                        text: FFLocalizations.of(context).getText(
                          'am1j6jbo' /* Apply Changes */,
                        ),
                        options: FFButtonOptions(
                          width: 310,
                          height: 55,
                          color: Color(0xFFA70000),
                          textStyle:
                              FlutterFlowTheme.of(context).subtitle2.override(
                                    fontFamily: 'Lexend Deca',
                                    color: FlutterFlowTheme.of(context).dark900,
                                  ),
                          elevation: 4,
                          borderSide: BorderSide(
                            color: FlutterFlowTheme.of(context).gray600,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(40, 20, 40, 0),
                      child: FFButtonWidget(
                        onPressed: () async {
                          final usersUpdateData = createUsersRecordData(
                            currentStatus: false,
                          );
                          await currentUserReference!.update(usersUpdateData);
                          await signOut();
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SignInWidget(),
                            ),
                          );
                        },
                        text: FFLocalizations.of(context).getText(
                          'y4kvsxmf' /* Log Out */,
                        ),
                        options: FFButtonOptions(
                          width: 310,
                          height: 55,
                          color: Color(0xFFA70000),
                          textStyle:
                              FlutterFlowTheme.of(context).subtitle2.override(
                                    fontFamily: 'Lexend Deca',
                                    color: FlutterFlowTheme.of(context).dark900,
                                  ),
                          elevation: 4,
                          borderSide: BorderSide(
                            color: FlutterFlowTheme.of(context).gray600,
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
