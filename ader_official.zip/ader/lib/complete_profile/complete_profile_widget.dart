import '../auth/auth_util.dart';
import '../backend/backend.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../main_page/main_page_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CompleteProfileWidget extends StatefulWidget {
  const CompleteProfileWidget({Key? key}) : super(key: key);

  @override
  _CompleteProfileWidgetState createState() => _CompleteProfileWidgetState();
}

class _CompleteProfileWidgetState extends State<CompleteProfileWidget> {
  TextEditingController? displayNameController;

  bool? albterolCheckValue;
  bool? aspirinCheckValue;
  bool? epiCheckValue;
  bool? prednisoneCheckValue;
  bool? albterolCarryCheckValue;
  bool? aspirinCarryCheckValue;
  bool? epiCarryCheckValue;
  bool? prednisoneCarryCheckValue;
  bool? cprCheckValue;
  bool? emtCheckValue;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    displayNameController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color(0xFFC70000),
        automaticallyImplyLeading: false,
        title: Text(
          FFLocalizations.of(context).getText(
            'dsnp4d65' /* Complete Your Profile */,
          ),
          textAlign: TextAlign.center,
          style: FlutterFlowTheme.of(context).title1.override(
                fontFamily: 'Lexend Deca',
                color: Colors.white,
                fontSize: 30,
              ),
        ),
        actions: [],
        centerTitle: false,
        elevation: 0,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Align(
              alignment: AlignmentDirectional(-0.88, 0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                child: Text(
                  FFLocalizations.of(context).getText(
                    'skjzr8f3' /* Enter your name: */,
                  ),
                  textAlign: TextAlign.start,
                  style: FlutterFlowTheme.of(context).title1.override(
                        fontFamily: 'Lexend Deca',
                        fontSize: 24,
                      ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(20, 20, 20, 0),
              child: TextFormField(
                controller: displayNameController,
                obscureText: false,
                decoration: InputDecoration(
                  labelText: FFLocalizations.of(context).getText(
                    '5xo0m673' /* Your Name */,
                  ),
                  labelStyle: FlutterFlowTheme.of(context).bodyText1,
                  hintText: FFLocalizations.of(context).getText(
                    'g878dno4' /* What name do you go by? */,
                  ),
                  hintStyle: FlutterFlowTheme.of(context).bodyText1,
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0x00000000),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(50),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0x00000000),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(50),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0x00000000),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(50),
                  ),
                  focusedErrorBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0x00000000),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(50),
                  ),
                  filled: true,
                  fillColor: FlutterFlowTheme.of(context).primaryBackground,
                  contentPadding:
                      EdgeInsetsDirectional.fromSTEB(20, 24, 20, 24),
                ),
                style: FlutterFlowTheme.of(context).subtitle2,
                keyboardType: TextInputType.name,
              ),
            ),
            Align(
              alignment: AlignmentDirectional(-0.8, 0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                child: Text(
                  FFLocalizations.of(context).getText(
                    '3627d32d' /* List your medications: */,
                  ),
                  textAlign: TextAlign.start,
                  style: FlutterFlowTheme.of(context).title1.override(
                        fontFamily: 'Lexend Deca',
                        fontSize: 24,
                      ),
                ),
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: albterolCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => albterolCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    'xo0jtj0j' /* Albuterol */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    'v0fm5lg4' /* ProAir, Ventolin, etc. (Prescr... */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: aspirinCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => aspirinCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    'ycnlh0lf' /* Aspirin */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    'vnhzcwo8' /* Chewable, Capsuled, etc. */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: epiCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => epiCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    'na5hnkxl' /* Epinephrine */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    '9tya2yrj' /* EpiPen, etc. (Prescribed) */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: prednisoneCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => prednisoneCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    'pwycoc7r' /* Prednisone / Prednisolone */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    'ev7cpggw' /* Deltasone, Rayos, etc. (Prescr... */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Align(
              alignment: AlignmentDirectional(-0.8, 0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 15, 0, 0),
                child: Text(
                  FFLocalizations.of(context).getText(
                    'c99rgmw0' /* List carried medications: */,
                  ),
                  textAlign: TextAlign.start,
                  style: FlutterFlowTheme.of(context).title1.override(
                        fontFamily: 'Lexend Deca',
                        fontSize: 24,
                      ),
                ),
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: albterolCarryCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => albterolCarryCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    'git9qfx8' /* Albuterol */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    '3spo9cic' /* ProAir, Ventolin, etc. (Prescr... */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: aspirinCarryCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => aspirinCarryCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    'm4a4y310' /* Aspirin */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    '5uwl6wsl' /* Chewable, Capsuled, etc. */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: epiCarryCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => epiCarryCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    'obtrq4u1' /* Epinephrine */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    '5lqbxxrw' /* EpiPen, etc. (Prescribed) */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: prednisoneCarryCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => prednisoneCarryCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    '7dspw14a' /* Prednisone / Prednisolone */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    '3oghqzj4' /* Deltasone, Rayos, etc. (Prescr... */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Align(
              alignment: AlignmentDirectional(-0.8, 0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 15, 0, 0),
                child: Text(
                  FFLocalizations.of(context).getText(
                    'dskm7k9e' /* List any qualifications: */,
                  ),
                  textAlign: TextAlign.start,
                  style: FlutterFlowTheme.of(context).title1.override(
                        fontFamily: 'Lexend Deca',
                        fontSize: 24,
                      ),
                ),
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: cprCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => cprCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    'dvk81mxx' /* CPR */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    'qw7gsdji' /* I have underwent AHA or equiva... */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Theme(
              data: ThemeData(
                unselectedWidgetColor: Color(0xFF95A1AC),
              ),
              child: CheckboxListTile(
                value: emtCheckValue ??= false,
                onChanged: (newValue) =>
                    setState(() => emtCheckValue = newValue!),
                title: Text(
                  FFLocalizations.of(context).getText(
                    '6e7x3y4a' /* EMT */,
                  ),
                  style: FlutterFlowTheme.of(context).title3.override(
                        fontFamily: 'Lexend Deca',
                        color: Color(0xFFC70000),
                      ),
                ),
                subtitle: Text(
                  FFLocalizations.of(context).getText(
                    'jkogwlf0' /* I am a state-certified and/or ... */,
                  ),
                  style: FlutterFlowTheme.of(context).subtitle2,
                ),
                tileColor: Color(0xFFF5F5F5),
                activeColor: Color(0xFFC70000),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0, 25, 0, 20),
              child: FFButtonWidget(
                onPressed: () async {
                  final usersUpdateData = createUsersRecordData(
                    needsAlbuterol: albterolCheckValue,
                    needsAspirin: aspirinCheckValue,
                    needsEpi: epiCheckValue,
                    needsPrednisone: prednisoneCheckValue,
                    hasAlbuterol: albterolCarryCheckValue,
                    hasAspirin: aspirinCarryCheckValue,
                    hasEpi: epiCarryCheckValue,
                    hasPrednisone: prednisoneCarryCheckValue,
                    knowsCpr: cprCheckValue,
                    isEmt: emtCheckValue,
                    displayName: displayNameController!.text,
                  );
                  await currentUserReference!.update(usersUpdateData);
                  await Navigator.pushAndRemoveUntil(
                    context,
                    PageTransition(
                      type: PageTransitionType.rightToLeft,
                      duration: Duration(milliseconds: 300),
                      reverseDuration: Duration(milliseconds: 300),
                      child: MainPageWidget(),
                    ),
                    (r) => false,
                  );
                },
                text: FFLocalizations.of(context).getText(
                  '390td496' /* Save Profile */,
                ),
                options: FFButtonOptions(
                  width: 230,
                  height: 60,
                  color: FlutterFlowTheme.of(context).primaryText,
                  textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                        fontFamily: 'Lexend Deca',
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                  elevation: 3,
                  borderSide: BorderSide(
                    color: Colors.transparent,
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(40),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
